#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <tchar.h>

using namespace std;

static DWORD get_process_id(const WCHAR* process_name) {
	DWORD process_id = 0;

	HANDLE snap_shot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (snap_shot == INVALID_HANDLE_VALUE)
		return process_id;

	PROCESSENTRY32W entry = {};
	entry.dwSize = sizeof(decltype(entry));

	if (Process32FirstW(snap_shot, &entry) == TRUE) {
		// Check if the first handle is the one we want.
		if (_wcsicmp(process_name, entry.szExeFile) == 0)
				process_id = entry.th32ProcessID;
		else {
		   while (Process32NextW(snap_shot, &entry) == TRUE) {
			   if (_wcsicmp(process_name, entry.szExeFile) == 0) {
					   process_id = entry.th32ProcessID;
						break;
					}
				}
			}
		}


	CloseHandle(snap_shot);

	return process_id;

}

static uintptr_t get_module_base(const DWORD pid, const wchar_t* module_name) {
	uintptr_t module_base = 0;

	// Snap-shot of process modules
	HANDLE snap_shot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
	if (snap_shot == INVALID_HANDLE_VALUE)
		return module_base;


	MODULEENTRY32W entry = {};
	entry.dwSize = sizeof(decltype(entry));

	if (Module32FirstW(snap_shot, &entry) == TRUE) {
		if (wcsstr(module_name, entry.szModule) != nullptr)
			module_base = reinterpret_cast<uintptr_t>(entry.modBaseAddr);
		else {
			while (Module32NextW(snap_shot, &entry) == TRUE) {
				if (wcsstr(module_name, entry.szModule) != nullptr) {
					module_base = entry.th32ProcessID;
					break;
				}
			}
		}
	}

	CloseHandle(snap_shot);
	return module_base;
}

namespace driver {
	namespace codes {
		// Used to setup the driver
		constexpr ULONG attach =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x696, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Read process memory
		constexpr ULONG read =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x697, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Write process memory
		constexpr ULONG write =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x698, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Terminate Process
		constexpr ULONG IOCTL_TERMINATE_PROCESS =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x699, METHOD_BUFFERED, FILE_ANY_ACCESS);

	} // namespace codes

	// Shared between user & kernel
	struct Request {
		HANDLE process_id;

		PVOID target;
		PVOID buffer;

		SIZE_T size;
		SIZE_T return_size;

	};


	// attaching to a process
	bool attach_to_process(HANDLE driver_handle,const DWORD pid) {
		Request r;
		r.process_id = reinterpret_cast<HANDLE>(pid);

		return DeviceIoControl(driver_handle, codes::attach, &r, sizeof(r), &r, sizeof(r), nullptr, nullptr);
	}


	// reading memory from a process
	template <class T>
	T read_memory(HANDLE driver_handle, const uintptr_t addr) {
		T temp = {};

		Request r;
		r.target = reinterpret_cast<void*>(addr);
		r.buffer = &temp;
		r.size = sizeof(T);

		DeviceIoControl(driver_handle, codes::read, &r, sizeof(r), &r, sizeof(r), nullptr, nullptr);

		return temp;
	}

	template <class T>
	void write_memory(HANDLE driver_handle, const uintptr_t addr, const T& value) {
		Request r;
		r.target = reinterpret_cast<PVOID>(addr);
		r.buffer = (PVOID)&value;
		r.size = sizeof(T);

		DeviceIoControl(driver_handle, codes::write, &r, sizeof(r), &r, sizeof(r), nullptr, nullptr);
	}

	// Terminating a process
	bool terminate_process(HANDLE driver_handle, const DWORD pid)
	{
		driver::Request r = { 0 }; // Initialize all fields to 0
		r.process_id = reinterpret_cast<HANDLE>(pid); // Put the PID in the struct

		return DeviceIoControl(
			driver_handle,
			codes::IOCTL_TERMINATE_PROCESS,
			&r, sizeof(r),  // Input is the struct
			&r, sizeof(r),  // Output is the struct
			nullptr, nullptr
		);
	}
}



int main() {
	DWORD pid_to_kill = 0;
	DWORD bytesReturned;
	string userResponse;

	const DWORD targetpid = get_process_id(L"ac_client.exe");

	if (targetpid != 0)
		printf("Found ac_client.exe with PID : %d\n", targetpid);

	if (targetpid == 0) {
		cout << "Process not found\n";
		//cin.get();
		//return 1;
	}
	OpenProcess(PROCESS_ALL_ACCESS, FALSE, targetpid);

	const HANDLE driver = CreateFile(L"\\\\.\\KM", GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING,
									 FILE_ATTRIBUTE_NORMAL, NULL);

	if (driver == INVALID_HANDLE_VALUE)
	{
		cout << "[-] Failed to get driver handle. Error: " << GetLastError() << "\n";
		cout << "    Check if the driver is loaded and the symbolic link matches.\n";
		cin.get();
		return 1;
	}

	else
	{
		cout << "[+] Got Handle to driver.\n";
	}


	
	// 3. Attach (If notepad was found) MIGHT BE USELESS DIRECT READ WORKS
	if (targetpid != 0) {
		if (driver::attach_to_process(driver, targetpid)) {
			cout << "[+] Attached to ac_client.exe process via Kernel.\n";
		}
		else
		{
			cout << "[-] Failed to Attach  ac_client.exe process via Kernel.\n";
		}
	}
	

	uintptr_t OFFSET_NUMPLAYERS = 0x0058AC0C;
	int players = driver::read_memory<DWORD>(driver, OFFSET_NUMPLAYERS);
	std::cout << "Players From Kernel: [ " << players << " ]" << std::endl;

	// 4. Manual Kill Input
	cout << "Enter the PID of the process you want to kill: ";
	cin >> pid_to_kill;


	// Use the specific terminate function we built to match the Kernel's expectation
	if (driver::terminate_process(driver, pid_to_kill)) 
	{
		cout << "[+] Terminate request sent to driver successfully!\n";
	}
	else
	{
		cout << "[-] Driver rejected the terminate request. Error: " << GetLastError() << "\n";
	}




		//BOOL ok = DeviceIoControl(driver, driver::codes::IOCTL_TERMINATE_PROCESS, &pId, sizeof(pId), NULL, 0, &bytesReturned, NULL);

		//if (!ok)
		//{
		//	cout << "DeviceIOControl Failed. Error " << GetLastError();
		//	cin.get();
		//	return 1;
		//}
		//else
		//{
		//	cout << "Request Sent to driver\n";
		//}

		CloseHandle(driver);
		cout << "\nDone. Press Enter to exit.";
		cin.ignore();
		cin.get();
		return 0;
	
}