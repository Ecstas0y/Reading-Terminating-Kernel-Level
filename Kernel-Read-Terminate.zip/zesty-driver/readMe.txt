Read & Terminate Process

x64 --Working
WIN32 --Working

x86 --NotWorking

