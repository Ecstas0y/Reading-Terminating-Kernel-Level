﻿#include <ntifs.h>
#include <ntddk.h>
//#define PROCESS_TERMINATE 0x0001 // Access right to terminate a proces C type
constexpr ULONG PROCESS_TERMINATE = 0x0001; // Access right to terminate a proces CPP type

extern "C" {
	NTKERNELAPI NTSTATUS IoCreateDriver(PUNICODE_STRING DriverName, PDRIVER_INITIALIZE InitializationFunction);
	NTKERNELAPI NTSTATUS MmCopyVirtualMemory(PEPROCESS SourceProcess, PVOID SourceAddress, PEPROCESS TartgetProcess, PVOID TargetAddress, SIZE_T BufferSize, KPROCESSOR_MODE PreviousMode,PSIZE_T ReturnSize);

	// process termination function
	NTSTATUS TerminateProcessByPid(_In_ HANDLE ProcessId,_In_ NTSTATUS ExitStatus)
	{
		NTSTATUS status;
		PEPROCESS Process = NULL;
		HANDLE ProcessHandle = NULL;

		// 1. Look up the EPROCESS structure by PID
		// PsLookupProcessByProcessId increments the reference count on the EPROCESS object.
		status = PsLookupProcessByProcessId(ProcessId, &Process);

		if (!NT_SUCCESS(status))
		{
			DbgPrint("TerminateProcessByPid: Failed to lookup process ID %p. Status: 0x%X\n", ProcessId, status);
			return status;
		}

		// 2. Open a kernel-mode handle to the process object
		// OBJ_KERNEL_HANDLE ensures the resulting handle can only be used in kernel mode.
		status = ObOpenObjectByPointer(
			Process,
			OBJ_KERNEL_HANDLE,
			NULL,
			PROCESS_TERMINATE,
			*PsProcessType,
			KernelMode,
			&ProcessHandle
		);

		// 3. Clean up the reference count from PsLookupProcessByProcessId immediately.
		// ObDereferenceObject must be called to balance the reference count.
		ObDereferenceObject(Process);

		if (!NT_SUCCESS(status))
		{
			DbgPrint("TerminateProcessByPid: Failed to open object by pointer for termination. Status: 0x%X\n", status);
			return status;
		}

		// 4. Terminate the process
		status = ZwTerminateProcess(ProcessHandle, ExitStatus); // Note: ZwTerminateProcess is used in kernel-mode

		// 5. Clean Up: Close the process handle
		ZwClose(ProcessHandle);

		if (NT_SUCCESS(status))
			DbgPrint("TerminateProcessByPid: Successfully killed PID %p.\n", ProcessId);

		return status;
	}



}

void debug_print(PCSTR text) {
#ifdef DEBUG
	KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, text));
#else
	UNREFERENCED_PARAMETER(text);
#endif
}

namespace driver {
	namespace codes {
		// Used to setup the driver
		constexpr ULONG attach =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x696, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Read process memory
		constexpr ULONG read =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x697, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Write process memory
		constexpr ULONG write =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x698, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

		// Terminate Process
		constexpr ULONG IOCTL_TERMINATE_PROCESS =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x699, METHOD_BUFFERED, FILE_ANY_ACCESS);

		// New: Check if driver is currently attached
		constexpr ULONG check_attach =
			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x700, METHOD_BUFFERED, FILE_SPECIAL_ACCESS);

	} // namespace codes

	// Shared between user & kernel
	struct Request {
		HANDLE process_id;

		PVOID target;
		PVOID buffer;

		SIZE_T size;
		SIZE_T return_size;

	};

	NTSTATUS create(PDEVICE_OBJECT device_object, PIRP irp) {
		UNREFERENCED_PARAMETER(device_object);
		irp->IoStatus.Status = STATUS_SUCCESS;
		irp->IoStatus.Information = 0;
		IoCompleteRequest(irp, IO_NO_INCREMENT);
		return irp->IoStatus.Status;
		//return STATUS_SUCCESS; the following warning is treated as an error
	}

	NTSTATUS close(PDEVICE_OBJECT device_object, PIRP irp) {
		UNREFERENCED_PARAMETER(device_object);
		irp->IoStatus.Status = STATUS_SUCCESS;
		irp->IoStatus.Information = 0;
		IoCompleteRequest(irp, IO_NO_INCREMENT);
		return irp->IoStatus.Status;
		//return STATUS_SUCCESS; the following warning is treated as an error
	}


	NTSTATUS device_control(PDEVICE_OBJECT device_object, PIRP irp)
	{
		UNREFERENCED_PARAMETER(device_object);

		debug_print("[+] Device control called.\n");

		NTSTATUS status = STATUS_UNSUCCESSFUL;

		// We need this tp determine which code was passed through.
		PIO_STACK_LOCATION stack_irp = IoGetCurrentIrpStackLocation(irp);

		// Access the request object sent from user mode
		auto request = reinterpret_cast<Request*>(irp->AssociatedIrp.SystemBuffer);

		if (stack_irp == nullptr || request == nullptr)
		{
			irp->IoStatus.Status = STATUS_INVALID_PARAMETER;
			IoCompleteRequest(irp, IO_NO_INCREMENT);
			return status;
			//return STATUS_INVALID_PARAMETER; the following warning is treated as an error
		}

		// The target process we want access to
		static PEPROCESS target_process = nullptr;
		const ULONG control_code = stack_irp->Parameters.DeviceIoControl.IoControlCode;

		switch (control_code) {
		case codes::attach:
			// Cleanup previous reference if we are attaching to a new process
			if (target_process != nullptr) {
				ObDereferenceObject(target_process);
				target_process = nullptr;
			}
			status = PsLookupProcessByProcessId(request->process_id, &target_process);
			break;

			/*
			BASIC READ
					case codes::read:
			if (target_process != nullptr) {
				status = MmCopyVirtualMemory(target_process, request->target,
					PsGetCurrentProcess(), request->buffer,
					request->size, KernelMode, &request->return_size);
			}
			break;


			BASIC WRITE
					case codes::write:
			if (target_process != nullptr) {
				status = MmCopyVirtualMemory(PsGetCurrentProcess(), request->buffer,
					target_process, request->target,
					request->size, KernelMode, &request->return_size);
				break;
				}

			*/

			// THIS READ MIGHT 50 50 for x86
		//case codes::read:
		//{
		//	if (target_process)
		//	{
		//		auto request =
		//			(Request*)irp->AssociatedIrp.SystemBuffer;

		//		// place data AFTER the struct
		//		PVOID kernelOut =
		//			(PUCHAR)irp->AssociatedIrp.SystemBuffer + sizeof(Request);

		//		SIZE_T bytes = 0;

		//		status = MmCopyVirtualMemory(
		//			target_process,
		//			request->target,
		//			PsGetCurrentProcess(),
		//			kernelOut,                 // ✅ CORRECT
		//			request->size,
		//			KernelMode,
		//			&bytes
		//		);

		//		request->return_size = bytes;
		//	}
		//	break;
		//}

		case codes::read:
			if (target_process != nullptr) {
				__try {
					status = MmCopyVirtualMemory(target_process, request->target, PsGetCurrentProcess(),
						request->buffer, request->size, KernelMode, &request->return_size);
				}
				__except (EXCEPTION_EXECUTE_HANDLER) {
					status = STATUS_ACCESS_VIOLATION;
				}
			}
			break;

		case codes::write:
			if (target_process != nullptr) {
				__try {
					status = MmCopyVirtualMemory(PsGetCurrentProcess(), request->buffer, target_process,
						request->target, request->size, KernelMode, &request->return_size);
				}
				__except (EXCEPTION_EXECUTE_HANDLER) {
					status = STATUS_ACCESS_VIOLATION;
				}
			}
			break;

		case codes::IOCTL_TERMINATE_PROCESS:
			if (stack_irp->Parameters.DeviceIoControl.InputBufferLength >= sizeof(Request))
			{
				// 2. Use the 'request' pointer already defined at the top of device_control
				if (request->process_id != NULL)
				{
					// 3. Call your termination function using the handle from the struct
					status = TerminateProcessByPid(request->process_id, STATUS_SUCCESS);
				}
				else
				{
					status = STATUS_INVALID_PARAMETER;
				}

				// Set info to 0 because we aren't sending a 'Request' struct back
				irp->IoStatus.Information = 0;
			}
			else
			{
				status = STATUS_BUFFER_TOO_SMALL;
			}
			break;

		case codes::check_attach:
			if (target_process != nullptr)
			{
				status = STATUS_SUCCESS;
			}
			else
			{
				status = STATUS_DEVICE_NOT_READY; // Or STATUS_NOT_FOUND
			}
			break;

		default:
			status = STATUS_INVALID_DEVICE_REQUEST;
			break;
		}


		irp->IoStatus.Status = status;
		// Only set sizeof(Request) if it wasn't a terminate call
		if (control_code != codes::IOCTL_TERMINATE_PROCESS)
		{
			irp->IoStatus.Information = sizeof(Request);
		}

		IoCompleteRequest(irp, IO_NO_INCREMENT);
		return status;


	} // namespace driver
}

NTSTATUS driver_main(PDRIVER_OBJECT driver_object, PUNICODE_STRING registry_path)
{
	UNICODE_STRING symbolic_link = {};

	UNREFERENCED_PARAMETER(registry_path);
	UNICODE_STRING device_name = {};
	RtlInitUnicodeString(&device_name, L"\\Device\\KM");
	RtlInitUnicodeString(&symbolic_link, L"\\DosDevices\\KM");

	// Create driver device obj.
	PDEVICE_OBJECT device_object = nullptr;
	NTSTATUS status = IoCreateDevice(driver_object, 0, &device_name, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &device_object);

	if (!NT_SUCCESS(status))
	{
		debug_print("[_] Failed to create driver device.\n");
		return status;
	}

	debug_print("[+] Driver device successfully created.\n");

	status = IoCreateSymbolicLink(&symbolic_link, &device_name);
	if (!NT_SUCCESS(status)) {
		debug_print("[-] Failed to establish symbolic link.\n");
		IoDeleteDevice(device_object);
		return status;
	}

	debug_print("[+] Driver symbolic link successfully established.\n");

	// Allow us to send small amounts of data between um/km
	SetFlag(device_object->Flags, DO_BUFFERED_IO);

	// Set the driver handlers to our function with our logic
	driver_object->MajorFunction[IRP_MJ_CREATE] = driver::create;
	driver_object->MajorFunction[IRP_MJ_CLOSE] = driver::close;
	driver_object->MajorFunction[IRP_MJ_DEVICE_CONTROL] = driver::device_control;
	ClearFlag(device_object->Flags, DO_DEVICE_INITIALIZING);

	debug_print("[+] Driver initialized successfully.\n");

	return status;
}

// KdMapper will call this "entry point" but params will be null
NTSTATUS DriverEntry()
{
	debug_print("[+] Omar 's lap\n!");

	UNICODE_STRING driver_name = {};
	RtlInitUnicodeString(&driver_name, L"\\Driver\\KM");
	return IoCreateDriver(&driver_name, &driver_main);
}